function power(base, exponent) {
    return Math.pow(base, exponent);
}

module.exports = { power };